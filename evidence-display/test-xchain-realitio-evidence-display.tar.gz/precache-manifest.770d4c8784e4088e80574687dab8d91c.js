self.__precacheManifest = [
  {
    "revision": "67dc50d7570cb7edaafa",
    "url": "./static/js/main.d95b1664.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "b9e1c7ee8ee7badcdd15",
    "url": "./static/js/2.c86c4d52.chunk.js"
  },
  {
    "revision": "07c9acf82a3cdea25507d5a46e07d9f6",
    "url": "./static/media/realitio_logo.07c9acf8.png"
  },
  {
    "revision": "c1f068467e85d08abfa91b57a20c0ef8",
    "url": "./index.html"
  }
];